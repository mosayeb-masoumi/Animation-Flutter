## 1.2.1
* Fix need paint 

## 1.2.0
* Improve Animation
* fix leakage

## 1.1.1
* Improve Performance

## 1.1.0
* Add onAnimationEnd

## 1.0.0
* Initial release
