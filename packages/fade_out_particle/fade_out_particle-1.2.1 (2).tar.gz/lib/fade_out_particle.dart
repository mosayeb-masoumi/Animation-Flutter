library fade_out_particle;

export 'src/fade_out_particle.dart';
