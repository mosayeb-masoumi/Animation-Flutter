FadeOutParticle is an animation for disappearing views like Text and Icon
<h1 align="center">
<img src="https://raw.githubusercontent.com/hoomanmmd/fade_out_particle/main/preview.gif" alt="FadeOutParticle" />
</h1>

# Installation
Add this line to your pubspec:
```yaml  
dependencies:  
 fade_out_particle: ^1.2.1
```  

## Usage
```dart
FadeOutParticle(
    disappear: true,
    child: Text('Fade out Particle'),
)
```

